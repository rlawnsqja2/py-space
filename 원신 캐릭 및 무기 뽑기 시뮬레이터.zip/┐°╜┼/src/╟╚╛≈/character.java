package 픽업;

import java.util.*;

public class character {
	static int Won = 0;
	static int Seok1 = 0;
	static String pick;
	static int b3 = 0;
	static int count = 0;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		Random a = new Random();
		b3 = a.nextInt(2) + 1;
		
		System.out.println("픽업 캐릭을 입력하세요.");
		pick = s.next();

		Big: for (int max = 0; max < 10; max++) {
			First: for (int k = 1; k < 2; k++) {
				Second: for (int f = 1; f < 2; f++) {
					Third: for (Won = 1; Won < 90; Won++) {
						Random r = new Random();
						int c = r.nextInt(2333) + 1;
						if (c <= 8) {
							System.out.println(pick + " 나왔다!! " + Won + "뽑\n");
							break First;
						} else if (c == 9) {
							System.out.println("데히아 나왔다!! " + Won + "뽑");
							count++;
							break Second;
						} else if (c == 10) {
							System.out.println("타이나리 나왔다!! " + Won + "뽑");
							count++;
							break Second;
						} else if (c == 11) {
							System.out.println("각청 나왔다!! " + Won + "뽑");
							count++;
							break Second;
						} else if (c == 12) {
							System.out.println("다이루크 나왔다!!" + Won + "뽑");
							count++;
							break Second;
						} else if (c == 13) {
							System.out.println("진 나왔다!! " + Won + "뽑");
							count++;
							break Second;
						} else if (c == 14) {
							System.out.println("치치 나왔다!! " + Won + "뽑");
							count++;
							break Second;
						}
					}
					{
						if (count == 0) {
							if (b3 == 1) {
								System.out.println("반천장에서 " + pick + " 나왔다!\n");
								break First;
							}
						}
					}
				}
				if (b3 == 2) {
					Random a1 = new Random();
					int b2 = a1.nextInt(7) + 1;
					if (b2 == 1) {
						System.out.println("캐릭 픽업 픽뚫 치치 나왔다.");
					} else if (b2 == 2) {
						System.out.println("캐릭 픽업 픽뚫 진 나왔다.");
					} else if (b2 == 3) {
						System.out.println("캐릭 픽업 픽뚫 다이루크 나왔다.");
					} else if (b2 == 4) {
						System.out.println("캐릭 픽업 픽뚫 모나 나왔다.");
					} else if (b2 == 5) {
						System.out.println("캐릭 픽업 픽뚫 각청 나왔다.");
					} else if (b2 == 6) {
						System.out.println("캐릭 픽업 픽뚫 타이나리 나왔다.");
					} else if (b2 == 7) {
						System.out.println("캐릭 픽업 픽뚫 데히아 나왔다.");
					}
				}

				for (Seok1 = 1; Seok1 < 90; Seok1++) {
					Random r = new Random();
					int c = r.nextInt(2333) + 1;
					if (c <= 15) {
						System.out.println(pick + " 나왔다!! " + (Won + Seok1) + "뽑\n");
						break First;
					}
				}
				System.out.println(pick + " 천장 찍었다 " + (Won + Seok1) + "뽑\n");
			}
		}
	}
}
