package 픽업;

import java.util.*;

public class weapon {
	static int a, a1, a2;
	static int count = 0;// 신의 궤도 운명의길 횟수
	static int count1 = 0;// 픽뚫 천장일때
	static int w = 0;
	static int sum = 0;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		Random r = new Random();

		System.out.println("현재 픽업 무기를 입력하세요.");
		String w1 = s.next();
		String w2 = s.next();

		System.out.println("신의궤도 운명의 길을 정하시오.");
		String god = s.next();
		Big: for (int z = 0; z < 10; z++) {
			if (w1.equals(god)) {
				count = 0;
				count1 =0;
				for (a = 0; a < 80; a++) {
					int nan = r.nextInt(5720) + 1;
					if (nan <= 15) {
						System.out.println("내가 원하는 " + w1 + "을(를) " + a + "뽑에 뽑았다.\n");
						count += 999;
						break;
					} else if ((nan > 15) && (nan <= 30)) {
						System.out.println("내가 원하지 않는 " + w2 + "을(를) " + a + "뽑에 뽑았다.");
						count++;
						break;
					} else if (nan == 31) {
						System.out.println("내가 원하지 않는 아모스의 활을 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 32) {
						System.out.println("내가 원하지 않는 매의 검을 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 33) {
						System.out.println("내가 원하지 않는 화박연을 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 34) {
						System.out.println("내가 원하지 않는 늑대의 말로를 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 35) {
						System.out.println("내가 원하지 않는 사풍원서를 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 36) {
						System.out.println("내가 원하지 않는 천공의 긍지를 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 37) {
						System.out.println("내가 원하지 않는 천공의 마루를 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 38) {
						System.out.println("내가 원하지 않는 천공의 두루마리를 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 39) {
						System.out.println("내가 원하지 않는 천공의 검을 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 40) {
						System.out.println("내가 원하지 않는 천공의 날개를 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					}
				}
				if (count == 0) { // 첫번째 천장
					Random r1 = new Random();
					int cheon = r1.nextInt(40) + 1;
					if (cheon <= 15) {
						System.out.println("첫 번째 천장에 내가 원하는 " + w1 + "을(를) 뽑았다.\n");
						count += 999;
					} else if ((cheon > 15) && (cheon <= 30)) {
						System.out.println("첫 번째 천장에 내가 원하지 않은 " + w2 + "을(를) 뽑았다.");
						count++;
					} else if (cheon == 31) {
						System.out.println("첫 번째 천장에 아모스의 활을 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 32) {
						System.out.println("첫 번째 천장에 매의 검을 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 33) {
						System.out.println("첫 번째 천장에 화박연을 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 34) {
						System.out.println("첫 번째 천장에 늑대의 말로를 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 35) {
						System.out.println("첫 번째 천장에 사풍원서를 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 36) {
						System.out.println("첫 번째 천장에 천공의 긍지를 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 37) {
						System.out.println("첫 번째 천장에 천공의 마루를 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 38) {
						System.out.println("첫 번째 천장에 천공의 두루마리를 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 39) {
						System.out.println("첫 번째 천장에 천공의 검을 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 40) {
						System.out.println("첫 번째 천장에 천공의 날개를 뽑았다.");
						count++;
						count1++; // 카운트=1 카운트1=1
					}
				}
				if ((count == 1) && (count1 == 0)) { // 1천장 내가 원하지 않은 픽업무기
					for (a1 = 0; a1 < 80; a1++) {
						Random r2 = new Random();
						int nan = r2.nextInt(5720) + 1;
						sum=a+a1;
						if (nan <= 15) {
							System.out.println("첫 번째 천장 이후에 내가 원하는 " + w1 + "을(를) " + sum + "뽑에 뽑았다.\n");
							count += 999;
							break;
						} else if ((nan > 15) && (nan <= 30)) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 " + w2 + "을(를) " + sum + "뽑에 뽑았다.");
							count++;
							break;
						} else if (nan == 31) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 아모스의 활을 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 32) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 매의 검을 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 33) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 화박연을 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 34) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 늑대의 말로를 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 35) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 사풍원서를 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 36) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 천공의 긍지를 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 37) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 천공의 마루를 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 38) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 천공의 두루마리를 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 39) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 천공의 검을 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 40) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 천공의 날개를 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						}
					}
					if ((count == 1) && (count1 == 0)) {
						Random r3 = new Random(); // 2번째 천장
						int cheon1 = r3.nextInt(40) + 1;
						if (cheon1 <= 15) {
							System.out.println("두 번째 천장에 내가 원하는 " + w1 + "을(를) 뽑았다.\n");
							count += 999;
						} else if ((cheon1 > 15) && (cheon1 <= 30)) {
							System.out.println("두 번째 천장에 내가 원하지 않은 " + w2 + "을(를) 뽑았다.");
							count++;
						} else if (cheon1 == 31) {
							System.out.println("두 번째 천장에 아모스의 활을 뽑았다.");
							count++;
						} else if (cheon1 == 32) {
							System.out.println("두 번째 천장에 매의 검을 뽑았다.");
							count++;
						} else if (cheon1 == 33) {
							System.out.println("두 번째 천장에 화박연을 뽑았다.");
							count++;
						} else if (cheon1 == 34) {
							System.out.println("두 번째 천장에 늑대의 말로를 뽑았다.");
							count++;
						} else if (cheon1 == 35) {
							System.out.println("두 번째 천장에 사풍원서를 뽑았다.");
							count++;
						} else if (cheon1 == 36) {
							System.out.println("두 번째 천장에 천공의 긍지를 뽑았다.");
							count++;
						} else if (cheon1 == 37) {
							System.out.println("두 번째 천장에 천공의 마루를 뽑았다.");
							count++;
						} else if (cheon1 == 38) {
							System.out.println("두 번째 천장에 천공의 두루마리를 뽑았다.");
							count++;
						} else if (cheon1 == 39) {
							System.out.println("두 번째 천장에 천공의 검을 뽑았다.");
							count++;
						} else if (cheon1 == 40) {
							System.out.println("두 번째 천장에 천공의 날개를 뽑았다.");
							count++;
						}
					}
					if (count == 2) {
						for (a2 = 0; a2 < 80; a2++) {
							Random r4 = new Random();
							int nan = r4.nextInt(572) + 1;
							sum=a+a1+a2;
							if (nan <= 4) {
								System.out.println("두 번째 천장 이후에 내가 원하는 " + w1 + "을(를) " + sum + "뽑에 뽑았다.\n");
								count++;
								break;
							}
						}
						if (count == 2) {
							System.out.println("세 번째 천장에 내가 원하는 " + w1 + "을(를) 뽑았다.\n");
						}
					}
				} if ((count == 1) && (count1 == 1)) { // 1천장 픽뚫 상태
					for (a1 = 0; a1 < 80; a1++) {
						Random r5 = new Random();
						int nan = r5.nextInt(286) + 1;
						sum=a+a1+a2;
						if (nan == 1) {
							System.out.println("첫 번째 픽뚫이후에 내가 원하는 " + w1 + "을(를) " + sum + "뽑에 뽑았다.\n");
							count += 999;
							break;
						} else if (nan == 2) {
							System.out.println("첫 번째 픽뚫 이후에 내가 원하지 않는 " + w2 + "을(를) " + sum + "뽑에 뽑았다.");
							count++;
							break;
						}
					}
					if ((count == 1) && (count1 == 1)) {
						Random r6 = new Random();
						int nan = r6.nextInt(2) + 1;
						if (nan == 1) {
							System.out.println("두 번째 천장에 내가 원하는 " + w1 + "을(를) 뽑았다.\n");
						} else if (nan == 2) {
							System.out.println("두 번째 천장에 내가 원하지 않은 " + w2 + "을(를) 뽑았다.");
							count++;
						}
						if ((count == 2) && (count1 == 1)) { // 1천장에서 픽뚫 2천장에서 원하지 않은 픽업 무기
							for (a2 = 0; a2 < 80; a2++) {
								sum=a+a1+a2;
								Random r7 = new Random();
								int nan1 = r7.nextInt(572) + 1;
								if (nan <= 4) {
									System.out.println(
										"두 번째 천장 이후에 내가 원하는 " + w1 + "을(를) " + sum + "뽑에 뽑았다.\n");
									count++;
									break;
								}
							}
							if (count == 2) {
								System.out.println("세 번째 천장에 내가 원하는 " + w1 + "을(를) 뽑았다.\n");
							}
						}
					}
				}
			} //신의 궤도 첫번째 완
			if (w2.equals(god)) {
				count = 0;
				count1 =0;
				for (a = 0; a < 80; a++) {
					int nan = r.nextInt(5720) + 1;
					if (nan <= 15) {
						System.out.println("내가 원하는 " + w2 + "을(를) " + a + "뽑에 뽑았다.\n");
						count += 999;
						break;
					} else if ((nan > 15) && (nan <= 30)) {
						System.out.println("내가 원하지 않는 " + w1 + "을(를) " + a + "뽑에 뽑았다.");
						count++;
						break;
					} else if (nan == 31) {
						System.out.println("내가 원하지 않는 아모스의 활을 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 32) {
						System.out.println("내가 원하지 않는 매의 검을 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 33) {
						System.out.println("내가 원하지 않는 화박연을 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 34) {
						System.out.println("내가 원하지 않는 늑대의 말로를 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 35) {
						System.out.println("내가 원하지 않는 사풍원서를 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 36) {
						System.out.println("내가 원하지 않는 천공의 긍지를 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 37) {
						System.out.println("내가 원하지 않는 천공의 마루를 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 38) {
						System.out.println("내가 원하지 않는 천공의 두루마리를 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 39) {
						System.out.println("내가 원하지 않는 천공의 검을 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					} else if (nan == 40) {
						System.out.println("내가 원하지 않는 천공의 날개를 " + a + "뽑에 뽑았다.");
						count++;
						count1++;
						break;
					}
				}
				if (count == 0) { // 첫번째 천장
					Random r1 = new Random();
					int cheon = r1.nextInt(40) + 1;
					if (cheon <= 15) {
						System.out.println("첫 번째 천장에 내가 원하는 " + w2 + "을(를) 뽑았다.\n");
						count += 999;
					} else if ((cheon > 15) && (cheon <= 30)) {
						System.out.println("첫 번째 천장에 내가 원하지 않은 " + w1 + "을(를) 뽑았다.");
						count++;
					} else if (cheon == 31) {
						System.out.println("첫 번째 천장에 아모스의 활을 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 32) {
						System.out.println("첫 번째 천장에 매의 검을 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 33) {
						System.out.println("첫 번째 천장에 화박연을 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 34) {
						System.out.println("첫 번째 천장에 늑대의 말로를 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 35) {
						System.out.println("첫 번째 천장에 사풍원서를 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 36) {
						System.out.println("첫 번째 천장에 천공의 긍지를 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 37) {
						System.out.println("첫 번째 천장에 천공의 마루를 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 38) {
						System.out.println("첫 번째 천장에 천공의 두루마리를 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 39) {
						System.out.println("첫 번째 천장에 천공의 검을 뽑았다.");
						count++;
						count1++;
					} else if (cheon == 40) {
						System.out.println("첫 번째 천장에 천공의 날개를 뽑았다.");
						count++;
						count1++; // 카운트=1 카운트1=1
					}
				}
				if ((count == 1) && (count1 == 0)) { // 1천장 내가 원하지 않은 픽업무기
					for (a1 = 0; a1 < 80; a1++) {
						Random r2 = new Random();
						int nan = r2.nextInt(5720) + 1;
						sum=a+a1;
						if (nan <= 15) {
							System.out.println("첫 번째 천장 이후에 내가 원하는 " + w2 + "을(를) " + sum + "뽑에 뽑았다.\n");
							count += 999;
							break;
						} else if ((nan > 15) && (nan <= 30)) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 " + w1 + "을(를) " + sum + "뽑에 뽑았다.");
							count++;
							break;
						} else if (nan == 31) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 아모스의 활을 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 32) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 매의 검을 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 33) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 화박연을 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 34) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 늑대의 말로를 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 35) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 사풍원서를 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 36) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 천공의 긍지를 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 37) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 천공의 마루를 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 38) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 천공의 두루마리를 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 39) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 천공의 검을 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						} else if (nan == 40) {
							System.out.println("첫 번째 천장 이후에 내가 원하지 않는 천공의 날개를 " + sum + "뽑에 뽑았다.");
							count++;
							count1++;
							break;
						}
					}
					if ((count == 1) && (count1 == 0)) {
						Random r3 = new Random(); // 2번째 천장
						int cheon1 = r3.nextInt(40) + 1;
						if (cheon1 <= 15) {
							System.out.println("두 번째 천장에 내가 원하는 " + w2 + "을(를) 뽑았다.\n");
							count += 999;
						} else if ((cheon1 > 15) && (cheon1 <= 30)) {
							System.out.println("두 번째 천장에 내가 원하지 않은 " + w1 + "을(를) 뽑았다.");
							count++;
						} else if (cheon1 == 31) {
							System.out.println("두 번째 천장에 아모스의 활을 뽑았다.");
							count++;
						} else if (cheon1 == 32) {
							System.out.println("두 번째 천장에 매의 검을 뽑았다.");
							count++;
						} else if (cheon1 == 33) {
							System.out.println("두 번째 천장에 화박연을 뽑았다.");
							count++;
						} else if (cheon1 == 34) {
							System.out.println("두 번째 천장에 늑대의 말로를 뽑았다.");
							count++;
						} else if (cheon1 == 35) {
							System.out.println("두 번째 천장에 사풍원서를 뽑았다.");
							count++;
						} else if (cheon1 == 36) {
							System.out.println("두 번째 천장에 천공의 긍지를 뽑았다.");
							count++;
						} else if (cheon1 == 37) {
							System.out.println("두 번째 천장에 천공의 마루를 뽑았다.");
							count++;
						} else if (cheon1 == 38) {
							System.out.println("두 번째 천장에 천공의 두루마리를 뽑았다.");
							count++;
						} else if (cheon1 == 39) {
							System.out.println("두 번째 천장에 천공의 검을 뽑았다.");
							count++;
						} else if (cheon1 == 40) {
							System.out.println("두 번째 천장에 천공의 날개를 뽑았다.");
							count++;
						}
					}
					if (count == 2) {
						for (a2 = 0; a2 < 80; a2++) {
							Random r4 = new Random();
							int nan = r4.nextInt(572) + 1;
							sum=a+a1+a2;
							if (nan <= 4) {
								System.out.println("두 번째 천장 이후에 내가 원하는 " + w2 + "을(를) " + sum + "뽑에 뽑았다.\n");
								count++;
								break;
							}
						}
						if (count == 2) {
							System.out.println("세 번째 천장에 내가 원하는 " + w2 + "을(를) 뽑았다.\n");
						}
					}
				} if ((count == 1) && (count1 == 1)) { // 1천장 픽뚫 상태
					for (a1 = 0; a1 < 80; a1++) {
						Random r5 = new Random();
						int nan = r5.nextInt(286) + 1;
						sum=a+a1+a2;
						if (nan == 1) {
							System.out.println("첫 번째 픽뚫이후에 내가 원하는 " + w2 + "을(를) " + sum + "뽑에 뽑았다.\n");
							count += 999;
							break;
						} else if (nan == 2) {
							System.out.println("첫 번째 픽뚫 이후에 내가 원하지 않는 " + w1 + "을(를) " + sum + "뽑에 뽑았다.");
							count++;
							break;
						}
					}
					if ((count == 1) && (count1 == 1)) {
						Random r6 = new Random();
						int nan = r6.nextInt(2) + 1;
						if (nan == 1) {
							System.out.println("두 번째 천장에 내가 원하는 " + w2 + "을(를) 뽑았다.\n");
						} else if (nan == 2) {
							System.out.println("두 번째 천장에 내가 원하지 않은 " + w1 + "을(를) 뽑았다.");
							count++;
						}
						if ((count == 2) && (count1 == 1)) { // 1천장에서 픽뚫 2천장에서 원하지 않은 픽업 무기
							for (a2 = 0; a2 < 80; a2++) {
								sum=a+a1+a2;
								Random r7 = new Random();
								int nan1 = r7.nextInt(572) + 1;
								if (nan <= 4) {
									System.out.println(
										"두 번째 천장 이후에 내가 원하는 " + w2 + "을(를) " + sum + "뽑에 뽑았다.\n");
									count++;
									break;
								}
							}
							if (count == 2) {
								System.out.println("세 번째 천장에 내가 원하는 " + w2 + "을(를) 뽑았다.\n");
							}
						}
					}
				}
			}//신의 궤도 두 번째 완료
		}
	}

}
