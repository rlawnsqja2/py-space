package week;

import java.util.*;

public class B {
		static int Won = 0;
		static int Seok1 = 0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("가챠 시뮬레이터");
		
		
		
		
			First:for(int k=1;k<2;k++) 
			{
				Second:for(int f=1;f<2;f++)
				{
					Third:for(Won = 1; Won < 90; Won++)
					{	
						Random r = new Random();
						int c = r.nextInt(23333)+1;
						if(c < 8)
						{
							System.out.println("픽업캐릭 나왔다!! "+Won+"뽑");
							break First;
						}
						else if(c == 9)
						{
							System.out.println("데히아 나왔다!! "+Won+"뽑");
							break Second;
						}
						else if(c == 10)
						{
							System.out.println("타이나리 나왔다!! "+Won+"뽑");
							break Second;
						}
						else if(c == 11)
						{
							System.out.println("각청 나왔다!! "+Won+"뽑");
							break Second;
						}
						else if(c == 12)
						{
							System.out.println("다이루크 나왔다!!"+Won+"뽑");
							break Second;
						}
						else if(c == 13)
						{
							System.out.println("진 나왔다!! "+Won+"뽑");
							break Second;
						}
						else if(c == 14)
						{
							System.out.println("치치 나왔다!! "+Won+"뽑");
							break Second;
						}
					}
					Random a = new Random();
					int b = a.nextInt(2);
					if(b==0) {
						System.out.println("반천장 픽업캐릭 나왔다!");
						break Second;
						}
				}
						System.out.println("캐릭 픽업 픽뚫");
			
						for(Seok1 = 1;Seok1<90;Seok1++)
						{
							Random r = new Random();
							int c = r.nextInt(23333)+1;
							if(c < 15)
							{
								System.out.println("픽업캐릭 나왔다!! "+(Won+Seok1)+"뽑");
								break First;
							}
						}	
						System.out.println("천장 찍었다 "+(Won+Seok1)+"뽑");
				}
			}

	}
